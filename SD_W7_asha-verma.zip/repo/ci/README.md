# GitLab CI configuration

GitLab expects `.gitlab-ci.yml` at the repository root. This submission keeps the substantive configuration in `ci/gitlab-ci.yml` because the Week 7 guide explicitly expects a `ci/` folder; the root file includes it.

Key behaviors:
- `workflow:rules` creates pipelines for `merge_request_event` and the default branch.
- `quality` compiles all Python files to catch syntax/import-time parsing errors.
- `pytest` executes all tests, creates JUnit and Cobertura reports, and enforces 85% minimum coverage.
- Neither job allows failure, so any failure makes the pipeline fail.

Project-level merge blocking must also be enabled in GitLab UI: **Settings > Merge requests > Merge checks > Pipelines must succeed**.
