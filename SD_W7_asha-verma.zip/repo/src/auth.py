import os
import secrets

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials

security = HTTPBasic()


def verify_credentials(credentials: HTTPBasicCredentials = Depends(security)) -> str:
    expected_username = os.getenv("API_USERNAME", "student")
    expected_password = os.getenv("API_PASSWORD", "week7-demo")

    username_ok = secrets.compare_digest(credentials.username.encode(), expected_username.encode())
    password_ok = secrets.compare_digest(credentials.password.encode(), expected_password.encode())

    if not (username_ok and password_ok):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Basic"},
        )
    return credentials.username
