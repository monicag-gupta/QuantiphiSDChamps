from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, HTTPException, Query, status
from sqlalchemy.orm import Session

from src.auth import verify_credentials
from src.db import Base, engine, get_db
from src.schemas import TaskCreate, TaskOut, TaskStatus, TaskUpdate
from src.service import create_task, get_task, list_tasks, update_task


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(bind=engine)
    try:
        yield
    finally:
        engine.dispose()


app = FastAPI(
    title="Task Tracker API",
    version="1.0.0",
    description="Week 7 capstone API used to demonstrate TDD, regression testing, and GitLab CI.",
    lifespan=lifespan,
)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/tasks", response_model=TaskOut, status_code=status.HTTP_201_CREATED)
def create_task_endpoint(
    payload: TaskCreate,
    _: str = Depends(verify_credentials),
    db: Session = Depends(get_db),
):
    return create_task(db, payload)


@app.get("/tasks", response_model=list[TaskOut])
def list_tasks_endpoint(
    status_filter: TaskStatus | None = Query(default=None, alias="status"),
    _: str = Depends(verify_credentials),
    db: Session = Depends(get_db),
):
    return list_tasks(db, status_filter)


@app.get("/tasks/{task_id}", response_model=TaskOut)
def get_task_endpoint(
    task_id: int,
    _: str = Depends(verify_credentials),
    db: Session = Depends(get_db),
):
    task = get_task(db, task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@app.patch("/tasks/{task_id}", response_model=TaskOut)
def update_task_endpoint(
    task_id: int,
    payload: TaskUpdate,
    _: str = Depends(verify_credentials),
    db: Session = Depends(get_db),
):
    task = get_task(db, task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return update_task(db, task, payload)
