from sqlalchemy import select
from sqlalchemy.orm import Session

from src.models import Task
from src.schemas import TaskCreate, TaskUpdate


def create_task(db: Session, payload: TaskCreate) -> Task:
    task = Task(**payload.model_dump())
    db.add(task)
    db.commit()
    db.refresh(task)
    return task


def get_task(db: Session, task_id: int) -> Task | None:
    return db.get(Task, task_id)


def list_tasks(db: Session, status: str | None = None) -> list[Task]:
    stmt = select(Task).order_by(Task.id)
    if status is not None:
        stmt = stmt.where(Task.status == status)
    return list(db.scalars(stmt).all())


def update_task(db: Session, task: Task, payload: TaskUpdate) -> Task:
    # Correct partial-update behavior: only fields explicitly provided are changed.
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(task, field, value)
    db.add(task)
    db.commit()
    db.refresh(task)
    return task
