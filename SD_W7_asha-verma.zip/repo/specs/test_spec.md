# Week 7 Test Specification — Task Tracker API

## 1. Purpose
This specification defines acceptance criteria and the test plan for the Week 7 production-trust gate. It is intentionally committed before the test suite and implementation changes for the Week 7 feature work.

## 2. Scope
The capstone is a FastAPI Task Tracker API. Protected task endpoints use HTTP Basic authentication and persist data through SQLAlchemy to SQLite.

## 3. Acceptance criteria

### AC-01 Health endpoint
- `GET /health` returns HTTP 200.
- The response body is `{"status": "ok"}`.

### AC-02 Authentication gate
- Task endpoints require HTTP Basic authentication.
- Missing or invalid credentials return HTTP 401.
- A `WWW-Authenticate: Basic` header is returned for authentication failures.

### AC-03 Create a task
- `POST /tasks` with valid data returns HTTP 201.
- The response contains a generated integer `id` and persists the submitted fields.
- A title shorter than 3 characters is rejected with HTTP 422.
- An unsupported priority or status is rejected with HTTP 422.

### AC-04 Read and list tasks
- `GET /tasks/{id}` returns HTTP 200 for an existing task.
- Unknown task IDs return HTTP 404 without leaking internals.
- `GET /tasks` returns a list and can filter by status.

### AC-05 Partial update
- `PATCH /tasks/{id}` changes only fields explicitly supplied by the client.
- Fields omitted from the request keep their existing values.
- This criterion protects against the seeded regression where a title-only patch reset status/priority.

### AC-06 Persistence
- A task created in one request can be retrieved in a later request from the test database.

### AC-07 CI gate
- GitLab CI runs for every merge request and for the default branch.
- Lint and tests are required jobs; failures make the pipeline fail.
- Pytest JUnit and Cobertura coverage reports are uploaded as GitLab artifacts.
- The test job fails when measured line coverage is below 85%.
- A successful merge-request pipeline is required before merge by enabling GitLab's **Pipelines must succeed** project setting.

## 4. Test pyramid

| Layer | Coverage | Examples |
|---|---|---|
| Unit | Fast, isolated behavior | Schema validation, service lookup with mocked DB session |
| Integration | API + dependency wiring + SQLite | Auth, create/read/list/update flows, validation, 404 behavior |
| Regression | Prevent known defect from returning | PATCH must preserve omitted status/priority fields |

## 5. Fixtures and mocks
- Pytest fixture creates a fresh temporary SQLite database per test.
- FastAPI dependency override injects the test DB session.
- Auth credentials are set in the test environment.
- `unittest.mock.MagicMock` isolates the service layer from SQLAlchemy in a unit test.

## 6. Definition of done
- All tests pass locally.
- Test pass rate is 100%.
- Coverage is at least 85%.
- Regression test is present and passes after the fix.
- GitLab merge-request pipeline is green.
- GitLab merge settings prevent merge when the pipeline has not succeeded.
