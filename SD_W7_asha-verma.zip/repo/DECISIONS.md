# DECISIONS

## D1 — Test-first acceptance criteria
`specs/test_spec.md` is the first Week 7 commit. It defines acceptance criteria, the test pyramid, fixtures, mocks, regression behavior, and CI expectations before the tests are committed.

## D2 — Test pyramid
Unit tests cover validation and an isolated service method with a mocked SQLAlchemy session. Integration tests use FastAPI TestClient with a fresh in-memory SQLite database. A dedicated regression test protects partial PATCH semantics.

## D3 — Regression choice
The seeded defect reset a task's omitted `status` and `priority` during a title-only PATCH. The regression test was committed before the implementation/fix. Git history shows the faulty implementation commit followed by the fix that uses `model_dump(exclude_unset=True)`.

## D4 — CI choice
GitLab CI is used. The root `.gitlab-ci.yml` includes `ci/gitlab-ci.yml`, keeping the evaluator-visible CI folder while using GitLab's conventional root entry point. The pipeline runs for merge-request events and the default branch.

## D5 — Required CI gate
`quality` and `pytest` are non-optional jobs. Pytest must fully pass, and coverage below 85% fails the job. JUnit and Cobertura reports are published as artifacts for GitLab's test and coverage views.

## D6 — Merge blocking
The repository alone cannot switch on a GitLab project setting. After pushing, the project Maintainer/Owner must enable **Settings > Merge requests > Merge checks > Pipelines must succeed**. This prevents merge without a successful pipeline.

## D7 — AI use
An AI assistant was used to help structure the sample API, tests, CI configuration, documentation, and verification workflow. All generated code was executed locally and the test suite was verified before packaging.
