# STATUS

## Week 7 checkpoint
- Test specification committed before the test suite: **Yes**
- Unit tests present: **Yes**
- Integration tests present: **Yes**
- Fixtures present: **Yes**
- Mock-based unit test present: **Yes**
- Seeded regression reproduced and then fixed: **Yes**
- Local test suite: **PASS**
- Local test pass rate: **100%**
- Local coverage: **94.81%**
- Coverage gate configured: **85% minimum**
- GitLab merge-request pipeline configuration: **Present**
- GitLab `Pipelines must succeed` setting: **Must be enabled in the student's GitLab project UI after push**
- Actual GitLab green-pipeline evidence: **Must be captured from the student's GitLab project after push**

No real credentials or database files are committed. The sample Basic Auth credentials are deliberately non-secret demonstration values and should be changed outside this exercise.
