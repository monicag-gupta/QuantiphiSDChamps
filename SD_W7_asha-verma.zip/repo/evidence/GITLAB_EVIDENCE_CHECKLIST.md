# GitLab Evidence Checklist

The files already in this folder are **local verification evidence**. They are not a substitute for a real GitLab merge-request pipeline.

After pushing to your GitLab project:

1. Create a feature branch, make a harmless documented change, push it, and open a Merge Request.
2. Confirm the MR pipeline contains both `quality` and `pytest` jobs and is green.
3. In **Settings > Merge requests > Merge checks**, enable **Pipelines must succeed**.
4. Demonstrate the gate once: create a temporary failing test or change an assertion, push, and capture evidence that the MR is blocked while the pipeline is red. Revert the deliberate failure immediately.
5. Push the fix and capture the final green pipeline and merge-ready status.
6. Save evidence in this folder, for example:
   - `gitlab_green_pipeline.png`
   - `gitlab_merge_blocked_on_failure.png`
   - `gitlab_pipeline_job_log.txt`
   - `gitlab_test_summary.png`
7. Do not fabricate GitLab evidence. It must come from your actual project.
