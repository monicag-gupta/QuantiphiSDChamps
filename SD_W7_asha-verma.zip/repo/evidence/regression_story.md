# Seeded Regression — Failing Then Passing

## Regression
A title-only `PATCH /tasks/{id}` incorrectly reset omitted `status` to `pending` and `priority` to `medium`.

## Red stage
The regression test was already present when the deliberately faulty implementation was committed. Running the dedicated test against commit `663a35a` produced the assertion failure saved in `regression_failing_stage.txt`: the API returned `pending` when the expected preserved status was `done`.

## Green stage
Commit `d5f55b2` fixed the defect by applying only fields explicitly supplied by the client using `payload.model_dump(exclude_unset=True)`. The final suite passes 12/12 tests.

## How to inspect history

```bash
git log --reverse --oneline --decorate
```

The sequence shows specification → tests → faulty implementation → regression fix → CI/evidence.
