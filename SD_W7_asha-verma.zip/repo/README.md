# Task Tracker API — Software Developer Week 7

Gateway 7: Testing, TDD and Continuous Integration — Checkpoint 2.

## Submission map

- `specs/test_spec.md` — acceptance criteria and test plan, committed before tests.
- `src/` — FastAPI capstone API.
- `tests/` — unit, integration, and regression tests using fixtures and a mock.
- `ci/` — GitLab CI configuration included by root `.gitlab-ci.yml`.
- `evidence/` — local verification evidence plus a template for real GitLab evidence.
- `STATUS.md` — honest completion status.
- `DECISIONS.md` — testing, CI, regression, and AI-use decisions.

## Requirements

- Python 3.12 recommended
- Git
- GitLab account/project for the final merge-request gate evidence

## Run from a clean clone

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements-dev.txt
pytest --cov=src --cov-report=term-missing --cov-fail-under=85
```

## Run the API

```bash
# Sample-only credentials; change them for non-demo use.
export API_USERNAME=student
export API_PASSWORD=week7-demo
uvicorn src.main:app --reload
```

On Windows PowerShell:

```powershell
$env:API_USERNAME="student"
$env:API_PASSWORD="week7-demo"
uvicorn src.main:app --reload
```

Open `http://127.0.0.1:8000/docs` for Swagger UI.

Example authenticated request:

```bash
curl -u student:week7-demo -X POST http://127.0.0.1:8000/tasks \
  -H "Content-Type: application/json" \
  -d '{"title":"CI assignment","status":"pending","priority":"high"}'
```

## GitLab CI

The root `.gitlab-ci.yml` includes `ci/gitlab-ci.yml`.

The pipeline:
1. Runs on every merge-request pipeline and on the default branch.
2. Runs a Python bytecode compilation quality check.
3. Runs pytest with JUnit output and coverage.
4. Fails if any test fails.
5. Fails if line coverage is below 85%.
6. Uploads JUnit and Cobertura reports.

After pushing the repository to GitLab, enable **Settings > Merge requests > Merge checks > Pipelines must succeed** so a failed or missing merge-request pipeline blocks merge.

## Verify TDD history

```bash
git log --reverse --oneline --decorate
```

You should see the test specification commit before the test commit, followed by implementation and the regression fix.

## Final GitLab evidence

This package cannot contain a genuine GitLab pipeline created in your personal project until you push it. Follow `evidence/GITLAB_EVIDENCE_CHECKLIST.md`, then add the exported/screenshot evidence to `evidence/` and commit it before creating your final submission zip.
