def test_health_is_public(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_protected_endpoint_requires_auth(client):
    response = client.get("/tasks")
    assert response.status_code == 401
    assert response.headers["www-authenticate"].lower() == "basic"


def test_invalid_credentials_are_rejected(client):
    response = client.get("/tasks", auth=("student", "wrong"))
    assert response.status_code == 401


def test_create_then_read_persists_task(client, auth):
    create = client.post(
        "/tasks",
        auth=auth,
        json={
            "title": "Build Week 7 tests",
            "description": "TDD and CI",
            "status": "in_progress",
            "priority": "high",
        },
    )
    assert create.status_code == 201
    task_id = create.json()["id"]

    read = client.get(f"/tasks/{task_id}", auth=auth)
    assert read.status_code == 200
    assert read.json()["title"] == "Build Week 7 tests"
    assert read.json()["status"] == "in_progress"


def test_create_rejects_bad_payload(client, auth):
    response = client.post(
        "/tasks",
        auth=auth,
        json={"title": "x", "priority": "urgent"},
    )
    assert response.status_code == 422


def test_unknown_task_returns_404(client, auth):
    response = client.get("/tasks/999", auth=auth)
    assert response.status_code == 404
    assert response.json() == {"detail": "Task not found"}


def test_list_can_filter_by_status(client, auth):
    client.post("/tasks", auth=auth, json={"title": "Pending item", "status": "pending"})
    client.post("/tasks", auth=auth, json={"title": "Done item", "status": "done"})

    response = client.get("/tasks?status=done", auth=auth)
    assert response.status_code == 200
    body = response.json()
    assert len(body) == 1
    assert body[0]["title"] == "Done item"
