from unittest.mock import MagicMock

from src.models import Task
from src.service import get_task


def test_get_task_uses_session_get():
    expected = Task(id=7, title="Mocked task", status="pending", priority="medium")
    db = MagicMock()
    db.get.return_value = expected

    actual = get_task(db, 7)

    db.get.assert_called_once_with(Task, 7)
    assert actual is expected
