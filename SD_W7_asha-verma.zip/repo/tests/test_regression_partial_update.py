def test_partial_update_preserves_omitted_fields(client, auth):
    """Regression: a title-only PATCH must not reset status or priority."""
    created = client.post(
        "/tasks",
        auth=auth,
        json={
            "title": "Original title",
            "status": "done",
            "priority": "high",
        },
    )
    assert created.status_code == 201
    task_id = created.json()["id"]

    updated = client.patch(
        f"/tasks/{task_id}",
        auth=auth,
        json={"title": "Renamed title"},
    )
    assert updated.status_code == 200
    body = updated.json()
    assert body["title"] == "Renamed title"
    assert body["status"] == "done"
    assert body["priority"] == "high"
