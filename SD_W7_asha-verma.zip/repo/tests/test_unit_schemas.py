import pytest
from pydantic import ValidationError

from src.schemas import TaskCreate


def test_task_create_accepts_valid_input():
    task = TaskCreate(title="Write tests", priority="high")
    assert task.title == "Write tests"
    assert task.status == "pending"
    assert task.priority == "high"


def test_task_create_rejects_short_title():
    with pytest.raises(ValidationError):
        TaskCreate(title="No")


def test_task_create_rejects_invalid_priority():
    with pytest.raises(ValidationError):
        TaskCreate(title="Valid title", priority="urgent")
